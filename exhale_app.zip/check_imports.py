# check_imports.py
import os
import sys

# Добавляем корень проекта в путь Python, чтобы он точно нашел 'app'
project_root = os.path.dirname(os.path.abspath(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)
    print(f"--- DEBUG: Добавлен путь: {project_root} ---")

print("\n--- Проверка импорта app.main.routes ---")
try:
    # Попробуем импортировать весь модуль routes
    from app.main import routes as main_module
    print(f"УСПЕХ: Модуль app.main.routes импортирован: {main_module}")
    # Теперь проверим наличие атрибута 'bp'
    if hasattr(main_module, 'bp'):
        print(f"УСПЕХ: Атрибут 'bp' найден в app.main.routes: {main_module.bp}")
    else:
        print("ОШИБКА: Атрибут 'bp' НЕ НАЙДЕН в app.main.routes!")
        # Посмотрим все атрибуты модуля, чтобы понять, что там есть
        print("Атрибуты модуля main:", dir(main_module))
except ImportError as e:
    print(f"ОШИБКА: Не удалось импортировать app.main.routes: {e}")
except Exception as e:
    print(f"ОШИБКА: Неожиданная ошибка при импорте main: {e}")


print("\n--- Проверка импорта app.auth.routes ---")
try:
    # Попробуем импортировать весь модуль routes
    from app.auth import routes as auth_module
    print(f"УСПЕХ: Модуль app.auth.routes импортирован: {auth_module}")
    # Теперь проверим наличие атрибута 'bp'
    if hasattr(auth_module, 'bp'):
        print(f"УСПЕХ: Атрибут 'bp' найден в app.auth.routes: {auth_module.bp}")
    else:
        print("ОШИБКА: Атрибут 'bp' НЕ НАЙДЕН в app.auth.routes!")
        # Посмотрим все атрибуты модуля
        print("Атрибуты модуля auth:", dir(auth_module))
except ImportError as e:
    print(f"ОШИБКА: Не удалось импортировать app.auth.routes: {e}")
except Exception as e:
    print(f"ОШИБКА: Неожиданная ошибка при импорте auth: {e}")

print("\n--- Проверка завершена ---")