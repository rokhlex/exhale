# passenger_wsgi.py
import os
import sys

# Добавляем путь к вашему проекту в sys.path, если нужно
# Обычно Passenger сам находит приложение, но иногда это полезно
# INTERP = "/home/your_ssh_user/путь/к/вашему/venv/bin/python" # Пример пути к интерпертатору venv
# if sys.executable != INTERP: os.execl(INTERP, INTERP, *sys.argv)

# Путь к вашему приложению Flask
# sys.path.append(os.getcwd()) # Добавляет текущую папку в пути

from run import app as application # Импортируем ВАШУ переменную app из run.py

# Если вы используете фабрику create_app:
# from app import create_app
# application = create_app()