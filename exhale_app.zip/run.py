# run.py
from app import create_app, db
from app.models import User, ExhaleLog # Импортируем модели для shell контекста

# Создаем экземпляр приложения Flask с помощью фабрики
app = create_app()

# Добавляем контекст для команды flask shell, чтобы удобно работать с БД
@app.shell_context_processor
def make_shell_context():
    return {'db': db, 'User': User, 'ExhaleLog': ExhaleLog}

if __name__ == '__main__':
    # Запускаем сервер разработки Flask
    # debug=True удобно для разработки (автоперезагрузка, отладчик),
    # НО НИКОГДА НЕ ИСПОЛЬЗУЙТЕ debug=True в продакшене!
    app.run(debug=True)
