# config.py
import os
from dotenv import load_dotenv

basedir = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(basedir, '.env'))

class Config:
    SECRET_KEY = os.environ.get('f3920de861ae769f0968a43ff89f1d21') or 'default-secret-key'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'instance', 'app.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = True
    # Добавляем токен бота в конфигурацию
    TELEGRAM_BOT_TOKEN = os.environ.get('7819713834:AAFeb8TO2JaUIBRD3vdCXa68u7gHh_IRrmw')
    if not TELEGRAM_BOT_TOKEN:
        print("!!! ВНИМАНИЕ: TELEGRAM_BOT_TOKEN не установлен в .env файле !!!")