# app/__init__.py
import os
import sys # Импортируем sys для отладки путей
import importlib # Импортируем importlib для отладки импорта
import traceback # Импортируем traceback для печати полных ошибок
from flask import Flask
from config import Config
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect

# --- Инициализация расширений ---
# Создаем экземпляры расширений до создания приложения
db = SQLAlchemy()
migrate = Migrate()
login = LoginManager()
csrf = CSRFProtect()

# Настраиваем Flask-Login
login.login_view = 'auth.login' # Имя эндпоинта для страницы входа (с учетом блюпринта 'auth')
login.login_message = 'Пожалуйста, войдите, чтобы получить доступ к этой странице.'
login.login_message_category = 'info' # Категория для flash-сообщений

# --- Фабрика приложения ---
def create_app(config_class=Config):
    """ Создает и конфигурирует экземпляр приложения Flask. """
    print("--- DEBUG (__init__): Запуск create_app ---")
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_class)
    print(f"--- DEBUG (__init__): Приложение Flask создано, конфигурация загружена из {config_class.__name__} ---")

    # Убедимся, что папка instance существует (для SQLite и др. файлов)
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass # Папка уже существует

    # Инициализация расширений с созданным приложением
    db.init_app(app)
    migrate.init_app(app, db)
    login.init_app(app)
    csrf.init_app(app)
    print("--- DEBUG (__init__): Расширения db, migrate, login, csrf инициализированы ---")

    # --- Регистрация блюпринтов ---
    print("--- DEBUG (__init__): Начало регистрации блюпринтов ---")

    # --- Блюпринт для основных маршрутов с подробной отладкой ---
    try:
        print("\n--- DEBUG (__init__): Попытка импорта для 'main' ---")
        print(f"--- DEBUG (__init__): (main) Текущий sys.path = {sys.path}")
        # Ищем спецификацию модуля .main.routes внутри пакета 'app'
        spec_main = importlib.util.find_spec('.main.routes', package='app')
        print(f"--- DEBUG (__init__): (main) Результат find_spec для '.main.routes': {spec_main}")

        if spec_main and spec_main.loader:
            print(f"--- DEBUG (__init__): (main) Спецификация и загрузчик найдены: {spec_main.loader}")
            # Импортируем модуль
            temp_main_module = importlib.import_module('.main.routes', package='app')
            print(f"--- DEBUG (__init__): (main) Модуль '.main.routes' импортирован как temp_main_module: {temp_main_module}")
            # Проверяем наличие атрибута 'bp'
            if hasattr(temp_main_module, 'bp'):
                print(f"--- DEBUG (__init__): (main) Атрибут 'bp' ЕСТЬ в temp_main_module!")
                main_bp = temp_main_module.bp
                print(f"--- DEBUG (__init__): (main) Значение main_bp: {main_bp}")
                # Регистрируем блюпринт
                app.register_blueprint(main_bp)
                print("--- INFO: main_bp УСПЕШНО зарегистрирован ---")
            else:
                print(f"--- ERROR: (main) Атрибут 'bp' ОТСУТСТВУЕТ в temp_main_module!")
                try:
                    print(f"--- DEBUG (__init__): (main) Содержимое (dir) temp_main_module: {dir(temp_main_module)}")
                except Exception as dir_e:
                    print(f"--- ERROR: (main) Не удалось получить dir для temp_main_module: {dir_e}")
        else:
            print(f"--- ERROR: (main) Не удалось найти спецификацию (find_spec) для '.main.routes' ---")
            main_routes_path = os.path.join(app.root_path, 'main', 'routes.py')
            print(f"--- DEBUG (__init__): (main) Проверка пути к файлу: {main_routes_path}")
            print(f"--- DEBUG (__init__): (main) Существует ли файл? {os.path.exists(main_routes_path)}")

        # Попытка стандартного импорта (на случай, если отладка не выявила проблему)
        if 'main' not in app.blueprints:
            print("--- DEBUG (__init__): (main) Попытка стандартного импорта 'from .main import bp' ---")
            from .main import bp as main_bp_std # Используем другое имя переменной на всякий случай
            app.register_blueprint(main_bp_std)
            print("--- INFO: main_bp УСПЕШНО зарегистрирован (стандартный импорт) ---")

    except ImportError as e:
        print(f"ОШИБКА ИМПОРТА (ImportError) при обработке main_bp: {e}")
    except Exception as e:
        print(f"НЕОЖИДАННАЯ ОШИБКА (Exception) при обработке main_bp: {e}")
        traceback.print_exc() # Печатаем полный traceback


    # --- Блюпринт для аутентификации с подробной отладкой ---
    try:
        print("\n--- DEBUG (__init__): Попытка импорта для 'auth' ---")
        print(f"--- DEBUG (__init__): (auth) Текущий sys.path = {sys.path}")
        # Ищем спецификацию модуля .auth.routes внутри пакета 'app'
        spec_auth = importlib.util.find_spec('.auth.routes', package='app')
        print(f"--- DEBUG (__init__): (auth) Результат find_spec для '.auth.routes': {spec_auth}")

        if spec_auth and spec_auth.loader:
             print(f"--- DEBUG (__init__): (auth) Спецификация и загрузчик найдены: {spec_auth.loader}")
             # Импортируем модуль
             temp_auth_module = importlib.import_module('.auth.routes', package='app')
             print(f"--- DEBUG (__init__): (auth) Модуль '.auth.routes' импортирован как temp_auth_module: {temp_auth_module}")
             # Проверяем наличие атрибута 'bp'
             if hasattr(temp_auth_module, 'bp'):
                 print(f"--- DEBUG (__init__): (auth) Атрибут 'bp' ЕСТЬ в temp_auth_module!")
                 auth_bp = temp_auth_module.bp
                 print(f"--- DEBUG (__init__): (auth) Значение auth_bp: {auth_bp}")
                 # Регистрируем блюпринт
                 app.register_blueprint(auth_bp, url_prefix='/auth') # Добавляем префикс для URL аутентификации
                 print("--- INFO: auth_bp УСПЕШНО зарегистрирован ---")
             else:
                 print(f"--- ERROR: (auth) Атрибут 'bp' ОТСУТСТВУЕТ в temp_auth_module!")
                 try:
                     print(f"--- DEBUG (__init__): (auth) Содержимое (dir) temp_auth_module: {dir(temp_auth_module)}")
                 except Exception as dir_e:
                      print(f"--- ERROR: (auth) Не удалось получить dir для temp_auth_module: {dir_e}")
        else:
             print(f"--- ERROR: (auth) Не удалось найти спецификацию (find_spec) для '.auth.routes' ---")
             auth_routes_path = os.path.join(app.root_path, 'auth', 'routes.py')
             print(f"--- DEBUG (__init__): (auth) Проверка пути к файлу: {auth_routes_path}")
             print(f"--- DEBUG (__init__): (auth) Существует ли файл? {os.path.exists(auth_routes_path)}")

        # Попытка стандартного импорта (на случай, если отладка не выявила проблему)
        if 'auth' not in app.blueprints:
            print("--- DEBUG (__init__): (auth) Попытка стандартного импорта 'from .auth import bp' ---")
            from .auth import bp as auth_bp_std # Используем другое имя переменной
            app.register_blueprint(auth_bp_std, url_prefix='/auth')
            print("--- INFO: auth_bp УСПЕШНО зарегистрирован (стандартный импорт) ---")

    except ImportError as e:
        print(f"ОШИБКА ИМПОРТА (ImportError) при обработке auth_bp: {e}")
    except Exception as e:
        print(f"НЕОЖИДАННАЯ ОШИБКА (Exception) при обработке auth_bp: {e}")
        traceback.print_exc()


    # --- Импорт моделей (важно для Flask-Migrate/Alembic) ---
    try:
        from app import models
        print("--- DEBUG (__init__): Модуль app.models импортирован ---")
    except ImportError as e:
        print(f"ОШИБКА: Не удалось импортировать app.models: {e}")

    print("--- DEBUG (__init__): Завершение create_app, возврат app ---")
    # Возвращаем готовый экземпляр приложения
    return app