# app/models.py
from datetime import datetime, timezone
# Убираем werkzeug.security - пароли не храним
# from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin # Оставляем UserMixin, если хотим использовать Flask-Login для сессий
from app import db, login

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True) # Оставляем как первичный ключ для связей
    telegram_id = db.Column(db.BigInteger, index=True, unique=True, nullable=False) # ID пользователя Telegram (он большой)
    username = db.Column(db.String(64), index=True, nullable=True) # nullable=True ОЧЕНЬ ВАЖНО
    first_name = db.Column(db.String(64), nullable=False) # Имя пользователя
    last_name = db.Column(db.String(64), nullable=True) # Фамилия (может отсутствовать)
    photo_url = db.Column(db.String(256), nullable=True) # Ссылка на фото профиля (опционально)
    last_seen = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc)) # Время последнего входа/активности

    # Связь с логами выдохов остается
    exhale_logs = db.relationship('ExhaleLog', backref='author', lazy='dynamic')

    # Методы set_password и check_password больше не нужны

    def __repr__(self):
        return f'<User (TG:{self.telegram_id}) {self.first_name}>'

# Модель ExhaleLog остается без изменений
class ExhaleLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, index=True, default=lambda: datetime.now(timezone.utc))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False) # Ссылается на User.id

    def __repr__(self):
        local_time = self.timestamp.astimezone().strftime('%Y-%m-%d %H:%M:%S')
        return f'<ExhaleLog {local_time} by User FK:{self.user_id}>'

# Функция для загрузки пользователя Flask-Login (если используем его для сессий)
@login.user_loader
def load_user(user_id):
    # Загружаем по первичному ключу таблицы User (User.id)
    return db.session.get(User, int(user_id))