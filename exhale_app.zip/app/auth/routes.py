# app/auth/routes.py
import hashlib
import hmac
import json
from time import time
from datetime import datetime, timezone
from urllib.parse import unquote, parse_qs
from flask import (
    Blueprint, flash, redirect, url_for,
    request, session, current_app, jsonify, abort
)
from flask_login import login_user, logout_user, current_user
from sqlalchemy import select
from app import db, csrf # Импортируем csrf
from app.models import User

bp = Blueprint('auth', __name__)

# --- Функция проверки initData (остается) ---
def validate_twa_init_data(init_data: str, bot_token: str, max_age_seconds: int = 3600) -> dict | None:
    """ Проверяет подлинность и свежесть данных из Telegram Web App initData. """
    try:
        parsed_data = dict(parse_qs(init_data))
        if "hash" not in parsed_data or "user" not in parsed_data:
            current_app.logger.warning("Отсутствует hash или user в initData")
            return None
        hash_received = parsed_data.pop("hash")[0]
        user_data_json = parsed_data.get("user", [""])[0]
        try: user_data_json = unquote(user_data_json)
        except Exception: pass
        user_data = json.loads(user_data_json)

        data_check_arr = [f"{key}={value[0]}" for key, value in sorted(parsed_data.items())]
        data_check_string = "\n".join(data_check_arr)

        secret_key = hmac.new("WebAppData".encode(), bot_token.encode(), hashlib.sha256).digest()
        calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

        if calculated_hash != hash_received:
            current_app.logger.warning("Неверный хэш в TWA initData")
            return None

        auth_date = int(parsed_data.get("auth_date", [0])[0])
        if time() - auth_date > max_age_seconds:
            current_app.logger.warning("TWA initData устарели")
            return None
        return user_data
    except Exception as e:
        current_app.logger.error(f"Ошибка валидации TWA initData: {e}", exc_info=True)
        return None

# --- Маршрут для валидации TWA данных (вызывается из JS) ---
@bp.route('/validate_twa', methods=['POST'])
@csrf.exempt # Отключаем CSRF для этого API эндпоинта
def validate_twa():
    """ Валидирует initData от TWA и логинит пользователя. """
    bot_token = current_app.config.get('TELEGRAM_BOT_TOKEN')
    if not bot_token:
        current_app.logger.error("Токен Telegram бота не сконфигурирован.")
        return jsonify(success=False, message="Ошибка конфигурации сервера."), 500

    init_data_string = request.data.decode('utf-8')
    if not init_data_string:
        return jsonify(success=False, message="Отсутствуют данные инициализации."), 400

    user_info = validate_twa_init_data(init_data_string, bot_token)
    if user_info is None:
         return jsonify(success=False, message="Ошибка валидации данных."), 403

    try:
        telegram_id = int(user_info.get('id'))
        first_name = user_info.get('first_name')
        last_name = user_info.get('last_name')
        username = user_info.get('username')

        if not telegram_id or not first_name:
             return jsonify(success=False, message="Неполные данные пользователя."), 400

        user = db.session.scalar(select(User).where(User.telegram_id == telegram_id))
        now = datetime.now(timezone.utc)
        if user is None:
            user = User(telegram_id=telegram_id, first_name=first_name, last_name=last_name, username=username, last_seen=now)
            db.session.add(user)
            db.session.commit()
            current_app.logger.info(f"Создан новый TWA пользователь: {user}")
        else:
            user.first_name = first_name; user.last_name = last_name; user.username = username; user.last_seen = now
            db.session.commit()
            current_app.logger.info(f"Обновлен TWA пользователь: {user}")

        login_user(user, remember=True)
        return jsonify(success=True)
    except ValueError:
        current_app.logger.error(f"Неверный telegram_id получен из TWA: {user_info.get('id')}")
        return jsonify(success=False, message="Неверный ID пользователя."), 400
    except Exception as e:
        current_app.logger.error(f"Ошибка при обработке TWA данных или работе с БД: {e}")
        db.session.rollback()
        return jsonify(success=False, message="Внутренняя ошибка сервера."), 500

# --- Стандартный маршрут выхода ---
@bp.route('/logout')
def logout():
    """ Обрабатывает выход пользователя из системы. """
    logout_user()
    flash('Вы успешно вышли.', 'info') # Flash сообщение может быть не видно в TWA
    # Просто перенаправляем на главную (которая снова потребует валидации)
    # или можно вернуть JSON ответ, если выход инициируется из JS TWA
    return redirect(url_for('main.index'))

# --- Маршрут /telegram_login УДАЛЕН ---
# --- Старый маршрут /telegram_callback УДАЛЕН ---