# app/main/routes.py
from flask import (
    Blueprint, flash, redirect, render_template, url_for
)
from flask_login import current_user, login_required
from sqlalchemy import select
from datetime import date, datetime, time, timezone

# --- Импорты из вашего приложения ---
from app import db
from app.models import ExhaleLog, User # Убедитесь, что модели импортированы

# --- Создание Blueprint ---
# Эта строка должна быть здесь, на верхнем уровне модуля
bp = Blueprint('main', __name__)
# print("--- DEBUG: Загружен app/main/routes.py, 'bp' создан ---") # Можно временно раскомментировать для отладки


# --- Маршруты (Views) ---

@bp.route('/')
@bp.route('/index')
def index():
    """ Отображает главную страницу. """
    if current_user.is_authenticated:
        today_start_utc = datetime.combine(date.today(), time.min, tzinfo=timezone.utc)
        today_end_utc = datetime.combine(date.today(), time.max, tzinfo=timezone.utc)

        exhale_count_today = db.session.scalar(
            select(db.func.count(ExhaleLog.id))
            .where(ExhaleLog.user_id == current_user.id)
            .where(ExhaleLog.timestamp >= today_start_utc)
            .where(ExhaleLog.timestamp <= today_end_utc)
        ) or 0

        return render_template('index.html', title='Главная', exhale_count=exhale_count_today)
    else:
        return render_template('index.html', title='Начните выдыхать!')


@bp.route('/exhale', methods=['POST'])
@login_required
def exhale():
    """ Обрабатывает нажатие кнопки 'Click to Exhale'. """
    log_entry = ExhaleLog(author=current_user)
    db.session.add(log_entry)
    db.session.commit()
    flash('Отлично! Вы сделали дыхательное упражнение.', 'success')
    return redirect(url_for('main.index'))


# --- Маршруты-заглушки ---

@bp.route('/calendar')
@login_required
def calendar():
    """ Отображает страницу-заглушку для календаря. """
    return render_template('calendar.html', title='Календарь стресса')


@bp.route('/charts')
@login_required
def charts():
    """ Отображает страницу-заглушку для графиков. """
    return render_template('charts.html', title='Графики')